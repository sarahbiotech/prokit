from .protein import Protein

__all__ = ["Protein"]
